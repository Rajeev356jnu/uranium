
    let word=("     functionUp     ")
    console.log(word.trim());
    console.log(word)

    module.exports.word=word

let word1= "my NAME";
word2=word1.toLowerCase();
console.log(word2)
module.exports.word1=word1


let word3= "my country"
word4=word3.toUpperCase();
    console.log(word4)
    module.exports.word3=word3


    let arr= ["january","feb","march","april","may","june","july","august","sep","oct","nov","dec"]
     console.log(_.chunk(arr,3))
     module.exports.arr=arr

     let arr1=[1,3,5,7,9,11,13,15,17,19]
     console.log(_.tail(arr1))
     module.exports.arr1=arr1

     let arr2=[2,3,5,6,7];
     let arr3=[2,3,9,0,8];
     let arr4=[2,3,8,7,6];
     let arr5=[2,3,5,1,0];
     let arr6=[2,1,3,4,5,6]
    let arr7= console.log(_.union(arr2),(arr3),(arr4),(arr5),(arr6))
     module.exports.arr7=arr7


     let obj=[[ "horror","The Shining"],["drama","Titanic"],["thriller","Shutter Island"],["fantasy","Pans Labyrinth"]]
     console.log(_.fromPairs[[ "horror","The Shining"],["drama","Titanic"],["thriller","Shutter Island"],["fantasy","Pans Labyrinth"]])
     module.exports.obj=obj
    