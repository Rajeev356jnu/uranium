let welcome = function(){
    console.log("welcome to my application. I am Rajeev Ranjan and a part of FunctionUp Uranium cohort")
}
module.exports.welcome=welcome